from setuptools import setup,find_packages

setup(
    name = "src",
    version = "0.0.1",
    description="MLOPS package",
    author = "Ansh",
    packages= find_packages(),
    license="MIT",
    author_email="anshdarji@gmail.com"


)